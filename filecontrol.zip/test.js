const fetch = require('node-fetch');  // for running in command line or node terminal
//  //  const bufferFrom = require('buffer-from');
//   // ////////////////////////////////customers////////////////////////////////////////////////////
// QUnit.module( "CUSTOMERS", function() { 
//     // Get customers
//     QUnit.test("Get customers ",async function (assert) {
//       url ='https://automation.signifi.club/api/customer/5772603';
//      customer_id = 5772603;
//       const response = await fetch('https://automation.signifi.club/api/customer/5772603', {///{customer_id} =5772603
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//              'url': "https://automation.signifi.club/api/customer/5772603"
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }
//            }
//       }); 
//      // Get customers/Employee
//     QUnit.test("Get customers/employee ",async function (assert) {
//       url ='https://automation.signifi.club/api/customer/5598848';
//       customer_id = 5772603;
//        const response = await fetch('https://automation.signifi.club/api/customer/5598848', {///{customer_id} =5772603
//              method: 'GET', //or PUT
//              headers: {
//                'Accept': 'application/json',
//                'Content-Type': 'application/json',
//                'X-Automation-Suite':  'Qunit',
//               'url': "https://automation.signifi.club/api/customer/5772603"
//              }}).catch((err)=>{
//                assert.ok(false, `Failed: ${err}`);
//              });
//             if(response){
//                if(response.status == 200){
//                  let data = await response.json();
//                  console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                  assert.ok(true, `Success: status-> ${response.status} `);
//                }else{
//                  assert.ok(false, `Failed: ${response.status} `);
//                }
//             }
//       }); 
//      // Get purchase limit Get method
//     QUnit.test("Get purchase limit ",async function (assert) {
//       url ='https://automation.signifi.club/api/customer/limit/1';
//       const response = await fetch('https://automation.signifi.club/api/customer/limit/1', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//              'url': "https://automation.signifi.club/api/customer/limit/1"
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }
//            }
//       }); 
//      //  Customer limit post method
//     QUnit.test("Customer limit_PUT",async function(assert){
//       url ='https://automation.signifi.club/api/customer/limit/2';
//         const response = await fetch('https://automation.signifi.club/api/customer/limit/2', {
//           method: 'PUT', //or PUT
//           headers: {
//             'Accept': 'application/json',
//             'Content-Type': 'application/json',
//             'Access-Control-Allow-Origin': '*',
//             'Access-Control-Allow-Methods': 'POST, GET, PUT',
//             'url': 'https://automation.signifi.club/api/customer/limit/2'
//           },
//           body: JSON.stringify({
//             "limit_id": "2",
//             "type": "Defaultfds1",
//             "limit_type": "categorydsf",
//             "limit_period": "six_month",
//             "product_id": null,
//             "limit_amount": "10.00",
//             "limit_quantity": "20",
//             "category": "Laptop Adapters",
//             "product_name": null
//         })
//         })
//          .catch((err)=>{
//           assert.ok(false, `Failed: ${err}`);
//          });
//         if(response){
//           if(response.status == 200){
//             let data = await response.json();
//             console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//             assert.ok(true, `Success: status-> ${response.status} `);
//           }else{
//             assert.ok(true, `Failed: ${response.status} `);
//           }
//        }
//       });
//     // Customer Post method
//     QUnit.test("CUSTOMER_POST",async function(assert){
//       url ='https://automation.signifi.club/api/customer';
//       const response = await fetch('https://automation.signifi.club/api/customer', {
//         method: 'POST',
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'POST, GET, PUT',
//           'url': 'https://automation.signifi.club/api/customer'
//         },
//         body: JSON.stringify({
//           "account":"jaccrggggg120567", //change the account and email then post
//           "name":"Jane Accrgggggg",
//           "email_address":"jaccrgggggg@outlook.com",
//           "active":"t",
//           "limit_amount":"0.00",
//           "limit_qty":"0",
//           "type":"employee",
//           "employee_type":"Default",
//           "employee_details":"jaccrgggggg@outlook.com"
//       })
//       }).catch((err)=>{
//         assert.ok(false, `Failed: ${err}`);
//       });
//       if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//           assert.ok(true, `Success: status-> ${response.status} `);
//         }else{
//           assert.ok(false, `Failed: ${response.status} `);
//       }}});
//      // create limit post
//     QUnit.test("create limit_POST",async function(assert){
//       url ='https://automation.signifi.club/api/customer/limit/2';
//         const response = await fetch('https://automation.signifi.club/api/customer/limit/2', {
//           method: 'POST', //or PUT
//           headers: {
//             'Accept': 'application/json',
//             'Content-Type': 'application/json',
//             'Access-Control-Allow-Origin': '*',
//             'Access-Control-Allow-Methods': 'POST, GET, PUT',
//             'url': 'https://automation.signifi.club/api/customer/limit/2'
//           },
//           body: JSON.stringify({
//             "limit_id": "110", // chane limit_id and type
//             "type": "Defadsghydu",
//             "limit_type": "category",
//             "limit_period": "six_months",
//             "product_id": null,
//             "limit_amount": "10.00",
//             "limit_quantity": "20",
//             "category": "Laptop Adapters",
//             "product_name": null
//         })
//         }).catch((err)=>{
//           assert.ok(false, `Failed: ${err}`);
//         });
//        if(response){
//           if(response.status == 200){
//             let data = await response.json();
//             console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//             assert.ok(true, `Success: status-> ${response.status} `);
//           }else{
//             assert.ok(false, `Failed: ${response.status} `);
//           }
//         }
//       });
//   });
  ////////////////////////kiosk//////////////////////////////////////////////////////////////////////////
//QUnit.module( "KIOSK", function() {
    QUnit.test("Get kiosk", async function (assert) {
      url ='https://automation.signifi.club/api/kiosk';
        const response = await fetch('https://automation.signifi.club/api/kiosk', {
             method: 'GET', 
             headers: {
               //YmFlNjYwY2MtYTUzZS00ZGI2LWI4NTctZTYwN2I2MDYxMTE1Og==
               //'Accept': 'application/json',
             //'Authorization': 'Basic YmFlNjYwY2MtYTUzZS00ZGI2LWI4NTctZTYwN2I2MDYxMTE1Og==',
             //'Authorization': 'Bearer bae660cc-a53e-4db6-b857-e607b6061115',
              //'authorization': 'Basic ' + Buffer.from ('bae660cc-a53e-4db6-b857-e607b6061115:').toString('base64'),
              //'content-type': 'text/plain',
              //'Sec-Fetch-Dest': 'empty',
              //'X-Automation-Suite':  'Qunit',
              // 'Access-Control-Allow-Origin': '*',
              // 'Access-Control-Allow-Methods': 'GET,HEAD,POST',
              ///////////////////////////////////mozilaaa////////////////
              'Access-Control-Allow-Origin': '*',
              'X-Automation-Suite':  'Qunit',
              'Host': 'automation.signifi.club',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
              'Accept-Language': 'en-US,en;q=0.5',
              'Accept-Encoding': 'gzip, deflate, br',
              'Connection': 'keep-alive',
              'Cookie': 'ci_session=j4tmovtiifn6aj3v1vum12k8ctrt6qbs',
              'Upgrade-Insecure-Requests': '1',
              'Authorization': 'Basic YmFlNjYwY2MtYTUzZS00ZGI2LWI4NTctZTYwN2I2MDYxMTE1Og==',
              // //////////////////////chrome//////////////////////////
              // 'Accept': 'application/json, text/plain, */*',
              // 'Sec-Fetch-Dest': 'empty',
              // 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
              // 'Authorization': 'Basic YmFlNjYwY2MtYTUzZS00ZGI2LWI4NTctZTYwN2I2MDYxMTE1Og==',
             'url':'https://automation.signifi.club/api/kiosk'
             }}).catch((err)=>{
               assert.ok(false, `Failed: ${err}`);
             });
            if(response){
               if(response.status == 200){
                 let data = await response.json();
                 console.log(data);
                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
                 assert.ok(true, `Success: status-> ${response.status} `);
               }else{
                 assert.ok(false, `Failed: ${response.status} `);
               }
            }
      });
    //kiosk update method
  //   QUnit.test("update kiosk_PUT", async function (assert) {
  //     url ='https://automation.signifi.club/api/kiosk/129911';
  //        const response = await fetch('https://automation.signifi.club/api/kiosk/129911', {
  //             method: 'PUT', 
  //             headers: {
  //               'Accept': 'application/json',
  //               'Authorization': 'Basic YmFlNjYwY2MtYTUzZS00ZGI2LWI4NTctZTYwN2I2MDYxMTE1Og==',
  //                //'authorization': 'Basic ' + Buffer.from ('bae660cc-a53e-4db6-b857-e607b6061115:').toString('base64'),
  //                'content-type': 'application/json',
  //               // 'X-Automation-Suite':  'Qunit',
  //                'Access-Control-Allow-Origin': '*',
  //                'Access-Control-Allow-Methods': 'GET,HEAD,POST',
  //               'url': "https://automation.signifi.club/api/kiosk/129911"
  //             },
  //             body: JSON.stringify({
  //               "attributes":[
  //                 {
  //                 "attributes":{
  //                 "tax_id":"1",
  //                 "name":"kioskTest4",
  //                 "is_online":"t",
  //                 "active":"t",
  //                 "address":"india"
  //                 },
  //                 "entity_attribute_id":348884,
  //                 "entity_id":238823,
  //                 "profile_id":2,
  //                 "group_id":1,
  //                 "language_id":2,
  //                 "attribute_set_id":586,
  //                 "action":"edit"
  //                 }
  //                 ],
  //                 "name":"",
  //                 "user_id":"",
  //                 "tax_id":null,
  //                 "id":"testQAKiosk",
  //                 "username":"testQAKiosk",
  //                 "profile_id":"61",
  //                 "group_id":"25",
  //                 "language_id":"3",
  //                 "role_id":"6",
  //                 "channel_id":"1",
  //                 "attribute_set_id":585,
  //                 "password":""
  //           }),
  //         }).catch((err)=>{
  //           assert.ok(false, `Failed: ${err}`);
  //         });
  //            if(response){
  //               if(response.status == 200){
  //                 let data = await response.json();
  //                 console.log(data);
  //                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
  //                 assert.ok(true, `Success: status-> ${response.status} `);
  //               }else{
  //                  let data = await response.json();
  //                  //console.log(data);
  //                 assert.ok(false, `Failed: ${response.status} `);
  //               }
  //             }
  //     });
  //      //kiosk Inventory Get method
  //   QUnit.test("Get Kiosk_inventory", async function (assert) {
  //     url ='https://automation.signifi.club/api/kiosk/KIOSK002/inventory';
  //       const response = await fetch('https://automation.signifi.club/api/kiosk/KIOSK002/inventory', {
  //            method: 'GET', 
  //            headers: {
  //             'Accept': 'application/json',
  //             'Authorization': 'Basic YmFlNjYwY2MtYTUzZS00ZGI2LWI4NTctZTYwN2I2MDYxMTE1Og==',
  //              //'authorization': 'Basic ' + Buffer.from ('bae660cc-a53e-4db6-b857-e607b6061115:').toString('base64'),
  //              'content-type': 'application/json',
  //              //'X-Automation-Suite':  'Qunit',
  //              'Access-Control-Allow-Origin': '*',
  //              'Access-Control-Allow-Methods': 'GET,HEAD,POST',
  //              'url': "https://automation.signifi.club/api/kiosk/KIOSK002/inventory"
  //            }}).catch((err)=>{
  //              assert.ok(false, `Failed: ${err}`);
  //            });
  //           if(response){
  //              if(response.status == 200){
  //                let data = await response.json();
  //                console.log(data);
  //                console.log(`Url: ${url} \n Success: status-> ${response.status} `);
  //                assert.ok(true, `Success: status-> ${response.status} `);
  //              }else{
  //                assert.ok(false, `Failed: ${response.status} `);
  //     }
  //   }
  // });
  
  // });
//   // /////////////////////////////media/////////////////////////////////////////////////////////////////
// QUnit.module( "MEDIA", function() { 
//     //   //  media size
//     QUnit.test("get media size ",async function (assert) {
//       url ='https://automation.signifi.club/api/media_size';
//           const response = await fetch('https://automation.signifi.club/api/media_size', {
//                 method: 'GET', //or PUT
//                 headers: {
//                   'Accept': 'application/json',
//                   'Content-Type': 'application/json',
//                   'X-Automation-Suite':  'Qunit',
//                  'url': "https://automation.signifi.club/api/media_size"
//                 }}).catch((err)=>{
//                   assert.ok(false, `Failed: ${err}`);
//                 });
//                if(response){
//                   if(response.status == 200){
//                     let data = await response.json();
//                     console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                     assert.ok(true, `Success: status-> ${response.status} `);
//                   }else{
//                     assert.ok(false, `Failed: ${response.status} `);
//                   }}
//       });
//     //Get Media Directory
//     QUnit.test("get media directory ",async function (assert) {
//       url ='https://automation.signifi.club/api/media_directory/1';
//       const response = await fetch('https://automation.signifi.club/api/media_directory/1', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//              'url': 'https://automation.signifi.club/api/media_directory/1'
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }}
//       });
//          //Get Media Metadata
// QUnit.test("get Media Metadata ",async function (assert) {
//       url ='https://automation.signifi.club/api/media/8152';
//       const response = await fetch('https://automation.signifi.club/api/media/8152', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//              'url': 'https://automation.signifi.club/api/media/8152'
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }}
//       });
//         //Upload Media
// QUnit.test("Upload Media",async function(assert){
//     /////
//     url ='https://automation.signifi.club/api/media';
//     const FormData = require('form-data');
//     const fs = require('fs')
    
//     let form = new FormData();
//     form.append('my_field', 'my value');
//     form.append('my_buffer', new Buffer(10));
//     form.append('my_file', fs.createReadStream('./img.jpg'));
//     ///  failed body 
//     // var FormData = require('form-data');
//     //       let formData = new FormData();
//     //       const fs = require('fs')
//     //       let file_name1 = "img.jpg";
//     //   //  fs.readFileSync(txtFile,'utf8');  
//     //       let file1= fs.createReadStream(file_name1);         
//     //       formData.append('0', file1, file_name1);
//     //     console.log(fs.createReadStream('./img.jpg'));
//          const response = await fetch('https://automation.signifi.club/api/media', {
//              method: 'POST',
//              headers: {
//                'Accept': 'application/form-data',
//                'Content-Type': 'application/json',
//                'Access-Control-Allow-Origin': '*',
//                'Access-Control-Allow-Methods': 'POST, GET, PUT',
//                'url': 'https://automation.signifi.club/api/media'
//              },
//              params: {
//                'action': 'upload'
//              },
//              body: form
//            }).catch((err)=>{
//              assert.ok(false, `Failed: ${err}`);
//            });
//            if(response){
//              if(response.status == 200){
//                let data = await JSON.stringify(response);
//                console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                assert.ok(true, `Success: status-> ${response.status} `);
//              }else{
//                assert.ok(false, `Failed: ${response.status} `);
//              }
//            }
//      });
//   });
//   // // ////////////////////////////////////product////////////////////////////////////////////////////
// QUnit.module( "PRODUCT", function() { 
//     //Product_API GET Method
//     QUnit.test("Product_API GET",async function (assert) {
//       url ='https://automation.signifi.club/api/product/7684';
//       const response = await fetch('https://automation.signifi.club/api/product/7684', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//               'url': 'https://automation.signifi.club/api/product/7684'
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }
//            }
//       });
//     //  //Product_API/inventory GET Method
//     QUnit.test("Product_APIinventory GET",async function (assert) {
//       url ='https://automation.signifi.club/api/product/7628/inventory';
//       const response = await fetch('https://automation.signifi.club/api/product/7628/inventory', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//               'url': "https://automation.signifi.club/api/product/7628/inventory",
//               'Access-Control-Allow-Origin': '*',
//               'Access-Control-Allow-Methods': 'POST, GET, PUT',
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//       }}});
//     // Create product post(error)
//     QUnit.test("Create product_POST",async function(assert){
//       url ='https://automation.signifi.club/api/product';
//       const response = await fetch('https://automation.signifi.club/api/product', {
//         method: 'POST', //or PUT
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',  
//           'Access-Control-Allow-Methods': 'POST, GET, PUT',
//           'url': 'https://automation.signifi.club/api/product'
//         },
//         body: JSON.stringify({
//           //sku: "1.1.1.208",
//           type: "phone",
//           name: "iPhone 7 Plus 128GB",
//           description: "<ul><li>Retina HD display with wide colour gamut and 3D Touch</li><li>5.5 inches (diagonal) 1920-by-1080-pixel resolution at 401 ppi</li><li>A10 Fus ion chip with 64-bit architecture</li><li>All-new 12MP wide-angle and telephoto cameras</li><li>4K video recording at 30 fps and 1080p HD video recording at 30 fps or 6 0 fps</li><li>iOS 10 and iCloud</li><li>Wi-Fi Calling</li></ul>",
//           image: "iPhone 7 Plus_ blk_tr.png",
//           thumbnail: "iPhone 7 Plus_ blk_tr.png",
//           price: "1219.00",
//           brand: "Apple",
//           platform: "iOS (Apple)",
//           os: "iOS 10",
//           processor: "A10 Fusion chip",
//           screen_size: "5.5\"",
//           display_type: "Retina HD display with wide colour gamut and 3D Touch",
//           resolution: "1920x1080 pixels",
//           camera: "All-new 12MP wide-angle and telephoto cameras",
//           capacity: "128GB",
//           categories: ["All Products", "Smartphones"  ],
//           employee_type: "Default"
//       })
//       }).catch((err)=>{
//           assert.ok(false, `Failed: ${err}`);
//         });
//         if(response){
//           if(response.status == 200){
//             let data = await response.json();
//             console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//             assert.ok(true, `Success: status-> ${response.status} `);
//           }else{
//             assert.ok(false, `Failed: ${response.status} `);
//           }
//         }
//       }); 
  
//   });
//     // //update product put (error -5-3-2020)
//     // QUnit.test("Update Product_put",async function(assert){
//     //   const response = await fetch('https://automation.signifi.club/api/product/', { // {product_id} =7710
//     //     method: 'PUT', //or PUT
//     //     headers: {
//     //       'Accept': 'application/json',
//     //       'Content-Type': 'application/json',
//     //       'Access-Control-Allow-Origin': '*',  
//     //       'Access-Control-Allow-Methods': 'POST, GET, PUT',
//     //       'url': 'https://automation.signifi.club/api/product/7710'
//     //     },
//     //     body: JSON.stringify({
//     //      //sku: "7710",
//     //       product_id ="",
//     //       type: "phone",
//     //       active:"true",
//     //       name: "iPhone X Plus 128GB",
//     //       description: "<ul><li>Retina HD display with wide colour gamut and 3D Touch</li><li>5.5 inches (diagonal) 1920-by-1080-pixel resolution at 401 ppi</li><li>A10 Fus ion chip with 64-bit architecture</li><li>All-new 12MP wide-angle and telephoto cameras</li><li>4K video recording at 30 fps and 1080p HD video recording at 30 fps or 6 0 fps</li><li>iOS 10 and iCloud</li><li>Wi-Fi Calling</li></ul>",
//     //       image: "iPhone 7 Plus_ blk_tr.png",
//     //       thumbnail: "iPhone 7 Plus_ blk_tr.png",
//     //       price: "1219.00",
//     //       brand: "Apple",
//     //       platform: "iOS (Apple)",
//     //       os: "iOS 10",
//     //       processor: "A10 Fusion chip",
//     //       screen_size: "5.5\"",
//     //       display_type: "Retina HD display with wide colour gamut and 3D Touch",
//     //       resolution: "1920x1080 pixels",
//     //       camera: "All-new 12MP wide-angle and telephoto cameras",
//     //       capacity: "128GB",
//     //       categories: ["All Products", "Smartphones"  ]
//     //   })
//     //   }).catch((err)=>{
//     //       assert.ok(false, `Failed: ${err}`);
//     //     });
//     //     if(response){
//     //       if(response.status == 200){
//     //         let data = await response.json();
//     //         console.log(data);
//     //         assert.ok(true, `Success: status-> ${response.status} `);
//     //       }else{
//     //         assert.ok(false, `Failed: ${response.status} `);
//     //       }
//     //     }
//     // }); 
//   // //////////////////////////////// service order& quotes////////////////////////////////////////
// QUnit.module( "SERVICE ORDERS AND QUOTES", function() { 
//     //get service order
//     QUnit.test("Service Order GET", async function (assert) {
//       url ='https://automation.signifi.club/api/service_order/${quote_id}';
//         const quote_id = 19878;
//           const response = await fetch(`https://automation.signifi.club/api/service_order/${quote_id}`, {//[quote_id]=19878
//                 method: 'GET', 
//                 headers: {
//                   'Accept': 'application/json',
//                   'Content-Type': 'application/json',
//                   'X-Automation-Suite':  'Qunit',
//                   'url': `https://automation.signifi.club/api/service_order/${quote_id}`
//                 }}).catch((err)=>{
//                   assert.ok(false, `Failed: ${err}`);
//                 });
//                if(response){
//                   if(response.status == 200){
//                     let data = await response.json();
//                     console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                     assert.ok(true, `Success: status-> ${response.status} `);
//                   }else{
//                     assert.ok(false, `Failed: ${response.status} `);
//                   }
//                }
//       });
//     //get Quote
//     QUnit.test("Quote GET", async function (assert) {
//       url ='https://automation.signifi.club/api/quote';
//         const response = await fetch(`https://automation.signifi.club/api/quote`, {
//               method: 'GET', 
//               headers: {
//                 'Accept': 'application/json',
//                 'Content-Type': 'application/json',
//                 'X-Automation-Suite':  'Qunit',
//                 'url': `https://automation.signifi.club/api/service_order/quote`
//               }}).catch((err)=>{
//                 assert.ok(false, `Failed: ${err}`);
//               });
//              if(response){
//                 if(response.status == 200){
//                   let data = await response.json();
//                   console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                   assert.ok(true, `Success: status-> ${response.status} `);
//                 }else{
//                   assert.ok(false, `Failed: ${response.status} `);
//                 }
//              }
//       });
//     //Update service order
//     QUnit.test("Update Service Order PUT", async function (assert) {
//       const quote_id = 1;
//       const url =`https://automation.signifi.club/api/service_order/${quote_id}`;
//         const response = await fetch(`https://automation.signifi.club/api/service_order/${quote_id}`, {//[quote_id]=19878
//               method: 'PUT', 
//               headers: {
//                 'Accept': 'application/json',
//                 'Content-Type': 'application/json',
//                 'X-Automation-Suite':  'Qunit',
//                 'url': `https://automation.signifi.club/api/service_order/${quote_id}`
//               },
//               body: JSON.stringify({
//                 "user_id": "1",    
//                 "subtotal": 0.00,     
//                 "subtotal_voided": 0.00,     
//                 "subtotal_refunded": 0.00,     
//                 "subtotal_invoiced": 0.00,     
//                 "discount": 0.00,     
//                 "discount_voided": 0.00,     
//                 "discount_refunded": 0.00,     
//                 "discount_invoiced": 0.00,     
//                 "tax": 0.00,     
//                 "tax_voided": 0.00,     
//                 "tax_refunded": 0.00,     
//                 "tax_invoiced": 0.00,     
//                 "total": 859.00,     
//                 "total_voided": 0.00,     
//                 "total_refunded": 0.00,     
//                 "total_invoiced": 0.00,     
//                 "total_paid": 0.00,     
//                 "customer": { "name": "Joey Fleming","account": "12345","email_address": "jfleming@signifi.com","active": "t"     },    
//                 "items": [{ "sku": "SERVICE",  "serial_number": "ABCDE"  }],     
//                 "type": "service",     
//                 "status": "cancelled"
//                     })
            
//             }).catch((err)=>{
//                 assert.ok(false, `Failed: ${err}`);
//               });
//              if(response){
//                 if(response.status == 200){
//                   let data = await response.json();
//                   assert.ok(true, `Success: status-> ${response.status} `);
//                   console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 }else{
//                   assert.ok(false, `Failed: ${response.status} `);
//                 }
//              }
//       });
//     //Update service order
//     QUnit.test("Create Service Order POST", async function (assert) {
//       url ='https://automation.signifi.club/api/service_order';
//         const response = await fetch(`https://automation.signifi.club/api/service_order`, {
//               method: 'POST', 
//               headers: {
//                 'Accept': 'application/json',
//                 'Content-Type': 'application/json',
//                 'X-Automation-Suite':  'Qunit',
//                 'url': `https://automation.signifi.club/api/service_order`
//               },
//               body: JSON.stringify({
//                 "user_id": "Specifies the kiosk where this is used.",    
//                 "type": "service",     
//                 "status": "pending_technician_dropoff",
//                 "reference": "[REFERENCE NUMBER]",
//                 "customer":"The customer assigned to the service order",
//                 "items":"The list of service order items",
//                 "code":"[RANDOM CODE]",
//                 "customer_uuid":"7e52b3f0-d6ec-40fd-b5c7-057a780108e2",
//                 "items": [{ "sku": "SERVICE",  "serial_number": "[ASSET SERIAL NUMBER]"  }],
//                     })
//             }).catch((err)=>{
//                 assert.ok(false, `Failed: ${err}`);
//               });
//              if(response){
//                 if(response.status == 200){
//                   let data = await response.json();
//                   console.log(data);
//                   console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                   assert.ok(true, `Success: status-> ${response.status} `);
//                 }else{
//                   assert.ok(false, `Failed: ${response.status} `);
//                 }
//              }
//       });
//   });
// //   /////////////////////////transaction/////////////////////////////////////////////////////////////
// QUnit.module( "TRANSACTION", function() {  

// QUnit.test("Get Transaction", async function (assert) {
//   url ='https://automation.signifi.club/api/transaction/19882';
//     transaction_id = 19883 ;
//     const response = await fetch('https://automation.signifi.club/api/transaction/19882', {//{transaction_id}=19883
//          method: 'GET', 
//          headers: {
//           'Accept': 'application/json',
//           'Authorization': 'Basic YmFlNjYwY2MtYTUzZS00ZGI2LWI4NTctZTYwN2I2MDYxMTE1Og==',
//            //'authorization': 'Basic ' + Buffer.from ('bae660cc-a53e-4db6-b857-e607b6061115:').toString('base64'),
//            'content-type': 'application/json',
//            //'X-Automation-Suite':  'Qunit',
//            'Access-Control-Allow-Origin': '*',
//            'Access-Control-Allow-Methods': 'GET,HEAD,POST',
//            'url': "https://automation.signifi.club/api/transaction/19882",
           
//          }}).catch((err)=>{
//            assert.ok(false, `Failed: ${err}`);
//          });
//         if(response){
//            if(response.status == 200){
//              let data = await response.json();
//              console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//              console.log(data);
//              assert.ok(true, `Success: status-> ${response.status} `);
//            }else{
//              assert.ok(false, `Failed: ${response.status} `);
//   }}});
// });
//   ////////////////////profiles//////////////////////////////////////////////////////////////////////////
// QUnit.module( "PROFILE", function() {
//     //   // profile PUT
// QUnit.test("Profile_PUT",async function(assert){
//       url ='https://automation.signifi.club/api/profile/4';
//         const response = await fetch('https://automation.signifi.club/api/profile/4', {
//           method: 'PUT', //or PUT
//           headers: {
//             'Accept': 'application/json',
//             'Content-Type': 'application/json',
//             'Access-Control-Allow-Origin': '*',
//             'Access-Control-Allow-Methods': 'POST, GET, PUT',
//             'url': 'https://automation.signifi.club/api/profile/4'
//           },  
//           body: JSON.stringify({
//             "name":"Walmart",
//             "parent_id":"1",
//             "label":"Walmart",
//             "level":"2",
//             "active":"t",
//             "parent":"Default"
//         })
//         });
//         if(response){
//           if(response.status == 200){
//             let data = await response.json();
//             console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//             assert.ok(true, `Success: status-> ${response.status} `);
//           }
//           else{
//             assert.ok(false, `Failed: ${response.status} `);
//         }
//       }
//   });
//     });
//   // // //////////////////attributes///////////////////////////////////////////////////////////////////////
// QUnit.module( "ATTRIBUTES", function() {
//     //   // get attributes
//     QUnit.test("Get Attributes",async function (assert) {
//       url ='https://automation.signifi.club/api/attribute/669';
//         const response = await fetch('https://automation.signifi.club/api/attribute/669', {
//               method: 'GET', //or PUT
//               headers: {
//                 'Accept': 'application/json',
//                 'Content-Type': 'application/json',
//                 'X-Automation-Suite':  'Qunit',
//                'url': "https://automation.signifi.club/api/attribute/669"
//               }}).catch((err)=>{
//                 assert.ok(false, `Failed: ${err}`);
//               });
    
//              if(response){
//                 if(response.status == 200){
//                   let data = await response.json();
//                   console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                   assert.ok(true, `Success: status-> ${response.status} `);
//                 }else{
//                   assert.ok(false, `Failed: ${response.status} `);
//       }} });  
//     //   // get attribute set
//     QUnit.test("Get Attribute Sets",async function (assert) {
//       url ='https://automation.signifi.club/api/attribute_set/612';
//           const response = await fetch('https://automation.signifi.club/api/attribute_set/612', {
//                 method: 'GET', //or PUT
//                 headers: {
//                   'Accept': 'application/json',
//                   'Content-Type': 'application/json',
//                   'X-Automation-Suite':  'Qunit',
//                  'url': "https://automation.signifi.club/api/attribute_set/612"
//                 }}).catch((err)=>{
//                   assert.ok(false, `Failed: ${err}`);
//                 });
//                if(response){
//                   if(response.status == 200){
//                     let data = await response.json();
//                     console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                     assert.ok(true, `Success: status-> ${response.status} `);
//                   }else{
//                     assert.ok(false, `Failed: ${response.status} `);
//       }}});
//     //  //  update attribute put
//     QUnit.test("Update attribute_PUT",async function(assert){
//       url ='https://automation.signifi.club/api/attribute/878';
//       const response = await fetch('https://automation.signifi.club/api/attribute/878', {
//         method: 'PUT',
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'PUT',
//           'url': 'https://automation.signifi.club/api/attribute/878'
//         },  
//         body: JSON.stringify({
//           "name":"modules",
//           "sort_order":"1",
//           "label":"My Module",
//           "type":"components",
//           "searchable":"f",
//           "hidden":"t",
//           "subtype":"modules",
//           "access":"user",
//           "localized":"t"
//       })
//       });
//       if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//           assert.ok(true, `Success: status-> ${response.status} `);
//         }
//         else{
//           assert.ok(false, `Failed: ${response.status} `);
//       }
//     }
//       });
//   });
//   // ////////////////////////user///////////////////////////////////////////////////////////////////////
//   QUnit.module( "USER", function() {
//     //  update user
//     QUnit.test("Update user_PUT",async function(assert){
//       url ='https://automation.signifi.club/api/user/testAdminUserQA';
//       username ="testAdminUserQA";
//       const response = await fetch('https://automation.signifi.club/api/user/testAdminUserQA', {
//         method: 'PUT',
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'PUT',
//           'url': 'https://automation.signifi.club/api/user/testAdminUserQA'
//         },  
//         body: JSON.parse(`{
//           "password":"dd",
//           "username":"testAdminUserQA",
//           "profile_id":"59",
//           "group_id":"1",
//           "language_id":"1",
//           "role_id":"6",
//           "channel_id":"1",
//           "attributes":[
//           {
//           "attributes":{
//           },
//           "entity_attribute_id":34883,
//           "entity_id":23822,
//           "profile_id":1,
//           "group_id":1,
//           "language_id":1,
//           "attribute_set_id":572,
//           "attribute_set_type":"user"
//           }
//           ],
//           "entity_id":23822,
//           "attribute_set_id":572,
//           "old_password":"dd"
//           }`)
//       });
//       if(response){
//         if(response.status == 200){
//           assert.ok(true, `Success: status-> ${response.statusText} `);
//           console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//         }
//         else{
//           assert.ok(false, `Failed: ${response.status} `);
//       }
//     }
//       }); 
//     });
//   ////////////////////////////notification//////////////////////////////////////////////////////////
// QUnit.module( "NOTIFICATION", function() { 
//     //  //get notification
// QUnit.test("Get Notification",async function (assert) {
//       url ='https://automation.signifi.club/api/notification';
//           const response = await fetch('https://automation.signifi.club/api/notification', {
//                 method: 'GET', //or PUT
//                 headers: {
//                   'Accept': 'application/json',
//                   'Content-Type': 'application/json',
//                   'X-Automation-Suite':  'Qunit',
//                  'url': "https://automation.signifi.club/api/notification"
//                 }}).catch((err)=>{
//                   assert.ok(false, `Failed: ${err}`);
//                 });
//                if(response){
//                   if(response.status == 200){
//                     let data = await response.json();
//                     console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                     assert.ok(true, `Success: status-> ${response.status} `);
//                   }else{
//                     assert.ok(false, `Failed: ${response.status} `);
//                   }
//       }});
//     // //post notification
// QUnit.test("Post Notification",async function(assert){
//       url ='https://automation.signifi.club/api/notification';
//       const response = await fetch('https://automation.signifi.club/api/notification', {
//         method: 'POST',
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'POST, GET, PUT',
//           'url': 'https://automation.signifi.club/api/notification'
//         },
//         body: JSON.stringify({
//           "user_id": "testAdminUserQA",
//            "alert_type": "Connectivity",     
//            "alert_level": "Info"
//       })
//       }).catch((err)=>{
//         assert.ok(false, `Failed: ${err}`);
//       });
//       if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//           assert.ok(true, `Success: status-> ${response.status} `);
//         }else{
//           assert.ok(false, `Failed: ${response.status} `);
//       }}});
//   });
//   ////////////////stockmap and slot////////////////////////////////////////////////////////////////
// QUnit.module( "STOCKMAP AND SLOT", function() {
//     // get stockmap
// QUnit.test("Get Stockmap",async function (assert) {
//        url ='https://automation.signifi.club/api/stockmap';
//            const response = await fetch('https://automation.signifi.club/api/stockmap', {
//                  method: 'GET',
//                  headers: {
//                    'Accept': 'application/json',
//                    'Content-Type': 'application/json',
//                    'X-Automation-Suite':  'Qunit',
//                   'url': "https://automation.signifi.club/api/stockmap"
//                  }}).catch((err)=>{
//                    assert.ok(false, `Failed: ${err}`);
//                  });
//                 if(response){
//                    if(response.status == 200){
//                      let data = await response.json();
//                      console.log(data);
//                      console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                      assert.ok(true, `Success: status-> ${response.status} `);
//                    }else{
//                      assert.ok(false, `Failed: ${response.status} `);
//                    }
//                 }
//   });
// QUnit.test("Get Stockmap slot",async function (assert) {
//        url ='https://automation.signifi.club/api/stockmap/slots/1';
//          const response = await fetch('https://automation.signifi.club/api/stockmap/slots/1', {
//                method: 'GET', 
//                headers: {
//                  'Accept': 'application/json',
//                  'Content-Type': 'application/json',
//                  'X-Automation-Suite':  'Qunit',
//                 'url': "https://automation.signifi.club/api/stockmap/slots/1"
//                }}).catch((err)=>{
//                  assert.ok(false, `Failed: ${err}`);
//                });
//               if(response){
//                  if(response.status == 200){
//                    let data = await response.json();
//                 console.log(data);
//                    console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                    assert.ok(true, `Success: status-> ${response.status} `);
//                  }else{
//                    assert.ok(false, `Failed: ${response.status} `);
//                  }
//               }
//   });
// QUnit.test("Create Stockmap_POST",async function(assert){
//        url ='https://automation.signifi.club/api/stockmap/slots';
//        const response = await fetch('https://automation.signifi.club/api/stockmap/slots', {
//          method: 'POST',
//          headers: {
//            'Accept': 'application/json',
//            'Content-Type': 'application/json',
//            'Access-Control-Allow-Origin': '*',
//            'Access-Control-Allow-Methods': 'POST',
//            'url': 'https://automation.signifi.club/api/stockmap/slots'
//          },  
//          body: JSON.stringify({
//        "label": "QA",   
//        "slot_type": "lane",   
//        "slot_x": "5",     
//        "slot_y": "7",   
//        "slot_z": "2",    
//        "slot_x_physical": "78", 
//        "slot_y_physical": "34",
//        "slot_z_physical": "34", 
//        "slot_x_offset": "34.6",     
//        "slot_y_offset": "56.6",     
//        "slot_z_offset": "67.8",     
//        "width": "56",     
//        "height": "168",     
//        "step": "3",     
//        "capacity": "456",    
//        "reference": "api",     
//        "status": "1",    
//        "stockmap_id": "1",     
//        "product_id": "7419"
//          })
//        });
//        if(response){
//          if(response.status == 200){
//            let data = await response.json();
//                 console.log(data);
//            assert.ok(true, `Success: status-> ${response.status} `);
//            console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//          }
//          else{
//            assert.ok(false, `Failed: ${response.status} `);
//        }
//      }
//   });    
// QUnit.test("Update Stockmap_GET",async function(assert){
//          var _id = 555;
//          url =`https://automation.signifi.club/api/stockmap/slots/${_id}`;
//          const response = await fetch(`${url}`, {
//            method: 'GET',
//            headers: {
//              'Accept': 'application/json',
//              'Content-Type': 'application/json',
//              'Access-Control-Allow-Origin': '*',
//              'Access-Control-Allow-Methods': 'GET',
//              'url': `${url}`
//            },  
//            // data: JSON.stringify({
//            //   "_id":`${_id}`,
//            //   "label": "QA",     
//            //   "slot_type": "lane",     
//            //   "slot_x": "5",     
//            //   "slot_y": "7",     
//            //   "slot_z": "2",     
//            //   "slot_x_physical": "78",     
//            //   "slot_y_physical": "34",     
//            //   "slot_z_physical": "34",     
//            //   "slot_x_offset": "34.6",     
//            //   "slot_y_offset": "56.6",     
//            //   "slot_z_offset": "67.8",     
//            //   "width": "56",     
//            //   "height": "168",     
//            //   "step": "3",     
//            //   "capacity": "456",     
//            //   "reference": "api",     
//            //   "status": "1",     
//            //   "stockmap_id": "1",     
//            //   "product_id": "7419",     
//            //   "cabinet_id": "1"
//            // })
//          });
//          if(response){
//            if(response.status == 200){
//              let data = await response.json();
//                 console.log(data);
//              assert.ok(true, `Success: status-> ${response.status} `);
//              console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//            }
//            else{
//              assert.ok(false, `Failed: ${response.status} `);
//          }
//        }
//   });  
// QUnit.test("Get slot information_GET",async function(assert){
//          var slot_id = 1932;
//          url =`https://automation.signifi.club/api/slot/${slot_id}`;
//          const response = await fetch(`${url}`, {
//            method: 'GET',
//            headers: {
//              'Accept': 'application/json',
//              'Content-Type': 'application/json',
//              'Access-Control-Allow-Origin': '*',
//              'Access-Control-Allow-Methods': 'GET',
//              'url': `${url}`
//            },  
//          });
//          if(response){
//            if(response.status == 200){
//              let data = await response.json();
//                 console.log(data);
//              assert.ok(true, `Success: status-> ${response.status} `);
//              console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//            }
//            else{
//              assert.ok(false, `Failed: ${response.status} `);
//          }
//        }
//   });
//   });
// //////////////////////group//////////////////////////////////////////////////////////////////
// QUnit.module( "GROUP", function() { 
//     //Group_API GET Method
//   QUnit.test("Group_API GET", async function (assert) {
//     url ='https://automation.signifi.club/api/group';
//         const response = await fetch('https://automation.signifi.club/api/group', {
//               method: 'GET', 
//               headers: {
//                 'Accept': 'application/json',
//                 'Content-Type': 'application/json',
//                 'X-Automation-Suite':  'Qunit',
//                 'url': "https://automation.signifi.club/api/group"
//               }}).catch((err)=>{
//                 assert.ok(false, `Failed: ${err}`);
//               });
//              if(response){
//                 if(response.status == 200){
//                   let data = await response.json();
//                   console.log(data);
//                   console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                   assert.ok(true, `Success: status-> ${response.status} `);
//                 }else{
//                   assert.ok(false, `Failed: ${response.status} `);
//                 }
//              }
//     });
//   });
// //////////////////////////////IMPORT DATA //////////////////////////////////////////////////////// 
// QUnit.module( "IMPORT DATA", function() { 
//   //  Import data post method
//   QUnit.test("Import data_PUT",async function(assert){
//     url ='https://automation.signifi.club/api/import';
//     debugger
//       const response = await fetch('https://automation.signifi.club/api/import', {
//         method: 'PUT', //or PUT
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'POST, GET, PUT',
//           'url': 'https://automation.signifi.club/api/import'
//         },
//         body: JSON.stringify({
//           "table": "employees", 
//           "file_name": "Kiosks.csv"
//       })
//       })
//        .catch((err)=>{
//          assert.ok(false, `Failed: ${err}`);
//        });
//       if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//           assert.ok(true, `Success: status-> ${response.status} `);
//         }else{
//           assert.ok(true, `Failed: ${response.status} `);
//         }
//      }
//     });
//   });
// // // ////////////////////////language////////////////////////////////////////////////////////////////
// QUnit.module( "LANGUAGE", function() {
//     QUnit.test("Get Languages", async function (assert) {
//      const url ='https://automation.signifi.club/api/language/';
//         const response = await fetch(url, {
//              method: 'GET', //or PUT
//              headers: {
//                'Accept': 'application/json',
//                'Content-Type': 'application/json',
//                'X-Automation-Suite':  'Qunit',
//               'url': url
//              }}).catch((err)=>{
//                assert.ok(false, `Failed: ${err}`);
//              });
//             if(response){
//                if(response.status == 200){
//                  let data = await response.json();
//                  assert.ok(true, `Url: ${url} \n Success: status-> ${response.status} `);
//                  console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                }else{
//                  assert.ok(false, `Failed: ${response.status} `);
//                }
//             }
//      });
//       // language put
// QUnit.test("LANGUAGE_PUT",async function(assert){
//      url =' https://automation.signifi.club/api/language/3';
//        const response = await fetch('https://automation.signifi.club/api/language/3', {
//          method: 'PUT', //or PUT
//          headers: {
//            'Accept': 'application/json',
//            'Content-Type': 'application/json',
//            'Access-Control-Allow-Origin': '*',
//            'Access-Control-Allow-Methods': 'PUT',
//            'url': 'https://automation.signifi.club/api/language/3'
//          },  
//          body: JSON.stringify({
//              language_id: "3",
//              name: "Spanish",
//              label: "spaintestqa",
//              level: "1",
//              parent_id: null,
//              parent: null
//        })
//        });
//        if(response){
//          if(response.status == 200){
//            let data = await response.json();
//            console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//            assert.ok(true, `Success: status-> ${response.status} `);
//          }
//          else{
//            assert.ok(false, `Failed: ${response.status} `);
//        }
//      }
//      });
//       // Language Post method
// QUnit.test("LANGUAGE_POST",async function(assert){
//      url ='https://automation.signifi.club/api/language';
//      const response = await fetch('https://automation.signifi.club/api/language', {
//        method: 'POST', //or PUT
//        headers: {
//          'Accept': 'application/json',
//          'Content-Type': 'application/json',
//          'Access-Control-Allow-Origin': '*',
//          'Access-Control-Allow-Methods': 'POST, GET, PUT',
//          'url': 'https://automation.signifi.club/api/language'
//        },
//        body: JSON.stringify({
//          "language_id": "3",  
//          "name": null,   
//          "label": null, 
//          "parent_id": null,   
//          "level": "1",  
//          "parent": null
//      })
//      }).catch((err)=>{
//        assert.ok(false, `Failed: ${err}`);
//      });
//      if(response){
//        if(response.status == 200){
//          let data = await response.json();
//          console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//          assert.ok(true, `Success: status-> ${response.status} `);
//        }else{
//          assert.ok(false, `Failed: ${response.status} `);
//        }
//      }
//   });
//   }); 
// //////////////////////components//////////////////////////////////////////////////////////////////
// QUnit.module( "COMPONENTS", function() {
//     //   // Component Get method
//     QUnit.test("Get Component",async function (assert) {
//       url ='https://automation.signifi.club/api/component';
//         const response = await fetch('https://automation.signifi.club/api/component', {
//               method: 'GET', //or PUT
//               headers: {
//                 'Accept': 'application/json',
//                 'Content-Type': 'application/json',
//                 'X-Automation-Suite':  'Qunit',
//                'url': "https://automation.signifi.club/api/component"
//               }}).catch((err)=>{
//                 assert.ok(false, `Failed: ${err}`);
//               })
//              if(response){
//                 if(response.status == 200){
//                   let data = await response.json();
//                   console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                   assert.ok(true, `Success: status-> ${response.status} `);
//                 }else{
//                   assert.ok(false, `Failed: ${response.status} `);
//                 }
//              } 
//       });
//     // // //  // create component post   (error 504)
//     QUnit.test("create component_POST",async function(assert){
//       const response = await fetch('https://automation.signifi.club/api/component', {
//         method: 'POST', //or PUT
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'POST, GET, PUT',
//           'url': 'https://automation.signifi.club/api/component'
//         },
//         body: JSON.stringify({
//           "name": "test008",   
//           "attribute_set_id": "591",     
//           "template_id": "368"
//       })
//       }).catch((err)=>{
//         assert.ok(false, `Failed: ${err}`);
//       });
//      if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(data);
//           assert.ok(true, `Success: status-> ${response.status} `);
//         }else{
//           assert.ok(false, `Failed: ${response.status} `);
//         }
//       }
//     });
//   });
// // ////////////////////////roles//////////////////////////////////////////////////////////////////////// 
//  QUnit.module( "ROLES", function() {
//   // get roles
//   QUnit.test("Get role",async function (assert) {
//     url ='https://automation.signifi.club/api/role/1';
//       const response = await fetch('https://automation.signifi.club/api/role/1', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//              'url': "https://automation.signifi.club/api/role/1"//{role_id}=1;
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }
//            }
//     });
//   // //  // create role post
//   QUnit.test("create role_POST",async function(assert){
//     url ='https://automation.signifi.club/api/role';
//     const response = await fetch('https://automation.signifi.club/api/role', {
//       method: 'POST', //or PUT
//       headers: {
//         'Accept': 'application/json',
//         'Content-Type': 'application/json',
//         'Access-Control-Allow-Origin': '*',
//         'Access-Control-Allow-Methods': 'POST, GET, PUT',
//         'url': 'https://automation.signifi.club/api/role'
//       },
//       body: JSON.stringify({
//         "name": "apirole",   
//         "label": "labelqa",     
//         "level": "5"
//     })
//     }).catch((err)=>{
//       assert.ok(false, `Failed: ${err}`);
//     });
//    if(response){
//       if(response.status == 200){
//         let data = await response.json();
//         console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//         assert.ok(true, `Success: status-> ${response.status} `);
//       }else{
//         assert.ok(false, `Failed: ${response.status} `);
//       }
//     }
//     });
//   });
// ////////////////////////reports/////////////////////////////////////////////////////////////
//  QUnit.module( "REPORT", function() {
//   //  // Get report item kiosk
//   QUnit.test("Get report item kiosk ",async function (assert) {
//     url ='https://automation.signifi.club/api/report/item';
//     const response = await fetch('https://automation.signifi.club/api/report/item', {
//           method: 'GET', //or PUT
//           headers: {
//             'Accept': 'application/json',
//             'Content-Type': 'application/json',
//             'X-Automation-Suite':  'Qunit',
//            'url': "https://automation.signifi.club/api/report/item",
           
//           }}).catch((err)=>{
//             assert.ok(false, `Failed: ${err}`);
//           });
//          if(response){
//             if(response.status == 200){
//               let data = await response.json();
//               console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//               assert.ok(true, `Success: status-> ${response.status} `);
//             }else{
//               assert.ok(false, `Failed: ${response.status} `);
//             }
//          }
         
//     }); 
//   });
// // /////////////////////////tags////////////////////////////////////////////////////////////////////
// QUnit.module( "TAGS", function() { 
//   //   // update tag_sets
//   QUnit.test("Get update tag sets",async function (assert) {
//     url ='https://automation.signifi.club/api/tag_set/14';
//       const response = await fetch('https://automation.signifi.club/api/tag_set/14', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//              'url': "https://automation.signifi.club/api/tag_set/14"
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }
//            }
//     });
//   //   //  get tags
//   QUnit.test("get tags ",async function (assert) {
//     url ='https://automation.signifi.club/api/tag_set/1';
//       const response = await fetch('https://automation.signifi.club/api/tag_set/1', {
//             method: 'GET', //or PUT
//             headers: {
//               'Accept': 'application/json',
//               'Content-Type': 'application/json',
//               'X-Automation-Suite':  'Qunit',
//              'url': "https://automation.signifi.club/api/tag_set/1"
//             }}).catch((err)=>{
//               assert.ok(false, `Failed: ${err}`);
//             });
//            if(response){
//               if(response.status == 200){
//                 let data = await response.json();
//                 console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                 assert.ok(true, `Success: status-> ${response.status} `);
//               }else{
//                 assert.ok(false, `Failed: ${response.status} `);
//               }
//            } 
//     });
//   // // create tag_set(correct)
//   QUnit.test("Create tag set_POST",async function(assert){
//     url ='https://automation.signifi.club/api/tag_set';
//     let test_tag = 14;
//     const response = await fetch('https://automation.signifi.club/api/tag_set', {
//       method: 'POST', //or PUT
//       headers: {
//         'Accept': 'application/json',
//         'Content-Type': 'application/json',
//         'url': 'https://automation.signifi.club/api/tag_set'
//       },
//       body: JSON.stringify({
//             "type": "testing",     "value": [test_tag] 
//     })
//     }).catch((err)=>{
//         assert.ok(false, `Failed: ${err}`);
//       });
//       if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//           assert.ok(true, `Success: status-> ${response.status} `);
//         }else{7
//           assert.ok(false, `Failed: ${response.status} `);
//         }
//       }
//     });  
//   });
// ////////////////////////////////////////TEMPLATES////////////////////////////////////////////
// QUnit.module( "TEMPLATES", function() { 
//   QUnit.test("Get Template", async function (assert) {
//     url ='https://automation.signifi.club/api/template/${template_id}';
//       const template_id = 3;
//         const response = await fetch(`https://automation.signifi.club/api/template/${template_id}`, {
//               method: 'GET', 
//               headers: {
//                 'Accept': 'application/json',
//                 'Content-Type': 'application/json',
//                 'X-Automation-Suite':  'Qunit',
//                 'url': `https://automation.signifi.club/api/template/${template_id}`
//               }}).catch((err)=>{
//                 assert.ok(false, `Failed: ${err}`);
//               });
//              if(response){
//                 if(response.status == 200){
//                   let data = await response.json();
//                   console.log(data);
//                   console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//                   assert.ok(true, `Success: status-> ${response.status} `);
//                 }else{
//                   assert.ok(false, `Failed: ${response.status} `);
//                 }
//              }
//              QUnit.module( "Module B" );		
//        QUnit.test( "test case 1", function( assert ) {
//           assert.ok( true, "Module B: in test case 1" );
//        });
//     });
//   QUnit.test("Update template_PUT",async function(assert){
//      var _id = 6990;
//     url =`https://automation.signifi.club/api/template/${_id}`;
//       const response = await fetch(`https://automation.signifi.club/api/template/${_id}`, {
//         method: 'PUT',
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'text/html',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'POST',
//           'url': `${url}`
//         },
//         body: JSON.stringify({
//           "Id":`${_id}`,
//           "name":"templateTesting001",
//           "description":"TestAPI",
//           "template":"<div class=\"admin-page\">\n\t<div class=\"general-header\">\n\t\t<img src=\"{{{media '/media/general-header.png'}}}\">\n\t</div><!--/general-catalog-header -->\n\n  <div class=\"main-container admin-container\">\n<div class=\"container-fluid\">\n<div class=\"row\">\n <div class=\"col-xs-12\">\n<div class=\"main-sub-container\">\n<div class=\"header-container\">\n<h2>{{{component.header}}}</h2>\n</div><!--/ header-container -->\n\n{{^if isLoggedIn}}\n\t<div class=\"admin-body-container {{isLoggedIn}}\">\n\t\t<div class=\"admin-keyboard-container\">\n\t\t\t<keyboard placeholder=\"Enter PIN\" append-locally=\"false\" max-length=\"6\" use-preview=\"true\" type=\"password\" {(^value)}=\"pin\"></keyboard>\n\t\t\t<div class=\"admin-keyboard-button-container\">\n\t\t\t\t<button type=\"submit\" class=\"btn btn-lg btn-primary\" id=\"admin-code-button\" ($click)=\"login\">\n\t\t\t\t\t\t\t\t\t\t\tEnter\n\t\t\t\t\t\t\t\t\t\t</button>\n\t\t\t</div><!--/ admin-keyboard-button-container -->\n\t\t</div>\n\t</div><!--/ admin-body-container -->\n            {{else}}\n\t            <!-- Admin Main Container -->\n\t            <div class=\"admin-body-container\">\n\t            \t<iscroll>\n\t            \t\t<div class=\"admin-button-container\">\n\t\t            \t\t<div class=\"admin-button\">\n\t\t            \t\t\t<a href=\"{{routeUrl section='stockmap'}}\">\n\t\t            \t\t\t\t<i class=\"fa fa-th fa-5x\" aria-hidden=\"true\"></i>\n\t\t            \t\t\t\t<span class=\"btn btn-lg btn-info\">Merchandise</span>\n\t\t            \t\t\t</a>\n\t\t            \t\t</div><!--/ admin-button-->\n\t\t              \t<div class=\"admin-button\">\n\t\t              \t\t<a href=\"{{routeUrl section='calibrate'}}\">\n\t\t              \t\t\t<i class=\"fa fa-crosshairs fa-5x\" aria-hidden=\"true\"></i>\n\t\t\t\t\t<span class=\"btn btn-lg btn-info\">Calibrate</span>\n\t\t              \t\t</a>\n\t\t              \t</div><!--/ admin-button-->\n\t            \t\t</div><!--/ admin-button-container -->\n\t            \t</iscroll>\n\t            </div><!--/ admin-body-container -->\n\t            <!-- Admin Main Container -->\n\t\t\t\t\t\t{{/if}}\n\n<div class=\"button-container\">\n<button type=\"button\" class=\"btn btn-lg btn-primary\" ($click)=\"app.backToHome\"><i class=\"fa fa-chevron-left\" aria-hidden=\"true\"></i> Back</button>\n            </div><!--/ button-container -->\n          </div><!--/ main-sub-container -->\n</div><!--/ col-xs-12 -->\n</div><!--/ row -->\n</div><!--/ container-fluid -->\n  </div><!--/ main-container stockmap-container -->\n\n  <!--/ footer : Starts -->\n  {{#is component.show_footer 't'}}\n  <footer {component}=\"footer\" />\n  {{/is}}\n  <!--/ footer : Ends  -->\n</div><!--/ admin-page -->" 
//       })
//       })
//        .catch((err)=>{
//          assert.ok(false, `Failed: ${err}`);
//        });
//       if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(data);
//           console.log(`Url: ${url} \n Success: status-> ${response.status}`);
//           assert.ok(true, `Success: status-> ${response.status}`);
//         }else{
//           assert.ok(true, `Failed: ${response.status}`);
//         }
//      }
//     });
//   QUnit.test("Approve Template Pending Updates_POST",async function(assert){
//     url ='https://automation.signifi.club/api/template_update';
//       const response = await fetch('https://automation.signifi.club/api/template_update', {
//         method: 'POST', 
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//           'Access-Control-Allow-Methods': 'POST',
//           'url': `${url}`
//         },
//         body: JSON.stringify({
//           "action": "approve",
//           "scheduled_at": null,
//           "data": [{"update_id": "6869"}] // change update id every time before entry
//       })
//       }).catch((err)=>{
//         assert.ok(false, `Failed: ${err}`);
//       });
//      if(response){
//         if(response.status == 200){
//           let data = await response.json();
//           console.log(data);
//           console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//           assert.ok(true, `Success: status-> ${response.status}`);
//         }else{
//           assert.ok(false, `Failed: ${response.status}`);
//         }
//       }
//     });
//     QUnit.test("Create Template_POST",async function(assert){
//       url ='https://automation.signifi.club/api/template';
//         const response = await fetch('https://automation.signifi.club/api/template', {
//           method: 'POST', 
//           headers: {
//             'Accept': 'application/json',
//             'Content-Type': 'text/html',
//             'Access-Control-Allow-Origin': '*',
//             'Access-Control-Allow-Methods': 'POST',
//             'url': `${url}`
//           },
//           body: JSON.stringify({
//             "name":"templateTesting002",// change name everytime before entry
//             "description":"TestAPI",
//             "template":"<div class=\"admin-page\">\n\t<div class=\"general-header\">\n\t\t<img src=\"{{{media '/media/general-header.png'}}}\">\n\t</div><!--/general-catalog-header -->\n\n  <div class=\"main-container admin-container\">\n<div class=\"container-fluid\">\n<div class=\"row\">\n <div class=\"col-xs-12\">\n<div class=\"main-sub-container\">\n<div class=\"header-container\">\n<h2>{{{component.header}}}</h2>\n</div><!--/ header-container -->\n\n{{^if isLoggedIn}}\n\t<div class=\"admin-body-container {{isLoggedIn}}\">\n\t\t<div class=\"admin-keyboard-container\">\n\t\t\t<keyboard placeholder=\"Enter PIN\" append-locally=\"false\" max-length=\"6\" use-preview=\"true\" type=\"password\" {(^value)}=\"pin\"></keyboard>\n\t\t\t<div class=\"admin-keyboard-button-container\">\n\t\t\t\t<button type=\"submit\" class=\"btn btn-lg btn-primary\" id=\"admin-code-button\" ($click)=\"login\">\n\t\t\t\t\t\t\t\t\t\t\tEnter\n\t\t\t\t\t\t\t\t\t\t</button>\n\t\t\t</div><!--/ admin-keyboard-button-container -->\n\t\t</div>\n\t</div><!--/ admin-body-container -->\n            {{else}}\n\t            <!-- Admin Main Container -->\n\t            <div class=\"admin-body-container\">\n\t            \t<iscroll>\n\t            \t\t<div class=\"admin-button-container\">\n\t\t            \t\t<div class=\"admin-button\">\n\t\t            \t\t\t<a href=\"{{routeUrl section='stockmap'}}\">\n\t\t            \t\t\t\t<i class=\"fa fa-th fa-5x\" aria-hidden=\"true\"></i>\n\t\t            \t\t\t\t<span class=\"btn btn-lg btn-info\">Merchandise</span>\n\t\t            \t\t\t</a>\n\t\t            \t\t</div><!--/ admin-button-->\n\t\t              \t<div class=\"admin-button\">\n\t\t              \t\t<a href=\"{{routeUrl section='calibrate'}}\">\n\t\t              \t\t\t<i class=\"fa fa-crosshairs fa-5x\" aria-hidden=\"true\"></i>\n\t\t\t\t\t<span class=\"btn btn-lg btn-info\">Calibrate</span>\n\t\t              \t\t</a>\n\t\t              \t</div><!--/ admin-button-->\n\t            \t\t</div><!--/ admin-button-container -->\n\t            \t</iscroll>\n\t            </div><!--/ admin-body-container -->\n\t            <!-- Admin Main Container -->\n\t\t\t\t\t\t{{/if}}\n\n<div class=\"button-container\">\n<button type=\"button\" class=\"btn btn-lg btn-primary\" ($click)=\"app.backToHome\"><i class=\"fa fa-chevron-left\" aria-hidden=\"true\"></i> Back</button>\n            </div><!--/ button-container -->\n          </div><!--/ main-sub-container -->\n</div><!--/ col-xs-12 -->\n</div><!--/ row -->\n</div><!--/ container-fluid -->\n  </div><!--/ main-container stockmap-container -->\n\n  <!--/ footer : Starts -->\n  {{#is component.show_footer 't'}}\n  <footer {component}=\"footer\" />\n  {{/is}}\n  <!--/ footer : Ends  -->\n</div><!--/ admin-page -->" 
//           })
//         }).catch((err)=>{
//           assert.ok(false, `Failed: ${err}`);
//         });
//        if(response){
//           if(response.status == 200){
//             let data = await response.json();
//             console.log(data);
//             console.log(`Url: ${url} \n Success: status-> ${response.status} `);
//             assert.ok(true, `Success: status-> ${response.status} `);
//           }else{
//             assert.ok(false, `Failed: ${response.status} `);
//           }
//         }
//     });
//     });