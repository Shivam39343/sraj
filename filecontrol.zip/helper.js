class test{
constructor(){
this.api_test= async function api_test(url, type, data, callback) {
    $.ajax(
      {
        url: url,
        type: type,
        processData: false,
        contentType: 'application/json; charset=utf-8',
        data: JSON.stringify(data),
        dataType: 'json',
        async: false,
        complete: function (result) {
          if (result.status == 0) {
            ok(false, '0 status - browser could be on offline mode');
          } else if (result.status == 404) {
            ok(false, '404 error');
          }
          else if (result.status == 200) {
            ok(true, 'Success');
          } 
          else {
            callback($.parseJSON(result.responseText));
          }
        }
      });
  }

  this.createCallUrl=async function createCallUrl(url,params) {
    const callUrl = url;
    for (var p in params) {
      callUrl += "/" + params[p];
    }

    return callUrl;
  }

this.UserAction()= async function UserAction() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
         if (this.readyState == 4 && this.status == 200) {
             alert(this.responseText);
         }
    };
    xhttp.open("GET", "https://automation.signifi.club/api/product", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    // xhttp.send("Your JSON Data Here");
}
}
}
  //module.exports= test;
