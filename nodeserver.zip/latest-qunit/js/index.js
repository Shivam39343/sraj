   //var buffer = new Buffer();
   //  var global = global || window;
   //    var Buffer = require('buffer/').Buffer;
   //var from = require('from/').Buffer;
   // var Buffer = new Buffer();
   //Register a callback to fire whenever a testsuite starts.
   QUnit.begin(function(details) {
       var data = document.getElementById("qunit-fixture").innerHTML;
       document.getElementById("qunit-fixture").innerHTML = "<br/>" +
           "QUnit.begin- Test Suite Begins " + "<br/>" +
           "Total Test: " + details.totalTests;
   });
   //Register a callback to fire whenever a test suite ends.		 
   QUnit.done(function(details) {
       var data = document.getElementById("qunit-testrunner-toolbar").innerHTML;
       document.getElementById("qunit-testrunner-toolbar").innerHTML = data + "<br/><br/>" +
           "QUnit.done - Test Suite Finised" + "<br/>" + "Total: " +
           details.total + " Failed: " + details.failed + " Passed: " + details.passed;
   });

   //Register a callback to fire whenever a module starts.
   QUnit.moduleStart(function(details) {
       var data = document.getElementById("qunit-fixture").innerHTML;
       document.getElementById("qunit-fixture").innerHTML = data + "<br/><br/>" +
           "QUnit.moduleStart - Module Begins " + "<br/>" + details.name;
   });

   //Register a callback to fire whenever a module ends.	  
   QUnit.moduleDone(function(details) {
       var data = document.getElementById("qunit-testrunner-toolbar").innerHTML;
       document.getElementById("qunit-testrunner-toolbar").innerHTML = data + "<br/><br/>" +
           "QUnit.moduleDone - Module Finished " + "<br/>" + details.name +
           " Failed/total: " + details.failed + "/" + details.total;
   });

   //Register a callback to fire whenever a test starts.
   QUnit.testStart(function(details) {
       var data = document.getElementById("qunit-fixture").innerHTML;
       document.getElementById("qunit-fixture").innerHTML = data + "<br/><br/>" +
           "QUnit.testStart - Test Begins " + "<br/>" + details.module + " " + details.name;

   });

   //Register a callback to fire whenever a test ends.
   QUnit.testDone(function(details) {
       var data = document.getElementById("qunit-testrunner-toolbar").innerHTML;
       document.getElementById("qunit-testrunner-toolbar").innerHTML = data + "<br/><br/>" +
           "QUnit.testDone - Test Finished " + "<br/>" + details.module + " " +
           details.name + "Failed/total: " + details.failed + " " + details.total +
           " " + details.duration;
   });

   QUnit.module("LANGUAGE", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("KISOK", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("COMPONENTS", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("ROLES", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("USER", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("STOCKMAP AND SLOT", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("ATTRIBUTES", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("PROFILE", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("QUOTES", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("TRANSACTION", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("NOTIFICATION", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("MEDIA", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("TAGS", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("PRODUCT", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("GROUP", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });
   QUnit.module("CUSTOMERS", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("IMPORT DATA", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("REPORT", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("SERVICE ORDERS AND QUOTES", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   QUnit.module("TEMPLATES", {
       beforeEach: function(assert) {
           assert.ok(true, "before test case");
       },
       afterEach: function(assert) {
           assert.ok(true, "after test case");
       }
   });

   // QUnit.test( "Get Languages", function( assert ) {
   //    assert.ok( true, "LANGUAGE : Get Languages" );
   // });

   // QUnit.test( "LANGUAGE_PUT", function( assert ) {
   //    assert.ok( true, "LANGUAGE: LANGUAGE_PUT" );
   // });

   //  QUnit.module( "KIOSK" );		
   // QUnit.test( "Get kiosk", function( assert ) {
   //    assert.ok( true, "KIOSK : Get kiosk" );
   // });

   // QUnit.test( "KIOSK", function( assert ) {
   //    assert.ok( true, "KIOSK : update kiosk_PUT" );
   // });	 

   // QUnit.test( "KIOSK", function( assert ) {
   //    assert.ok( true, "KIOSK : Get Kiosk_inventory" );
   // });	 

   // // QUnit.module( "COMPONENTS" );		
   // QUnit.test( "Get kiosk", function( assert ) {
   //    assert.ok( true, "KIOSK : Get Component" );
   // });

   // QUnit.test( "COMPONENTS", function( assert ) {
   //    assert.ok( true, "KIOSK : create component_POST" );
   // });	 

   // QUnit.test( "ROLES", function( assert ) {
   //    assert.ok( true, "KIOSK : Get role" );
   // });	 

   // QUnit.test( "ROLES", function( assert ) {
   //    assert.ok( true, "KIOSK : create role_POST" );
   // });