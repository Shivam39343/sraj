﻿'use strict';
var express = require('express')
var fs = require('fs')
var https = require('https')
var app = express()
var bodyParser = require('body-parser');
var routes = require('./routes/index');
var cors = require ('cors');
const port = process.env.PORT || 3000;
app.use(cors())
app.use('/module', express.static(__dirname + '/node_modules'));
app.use('/js', express.static(__dirname + '/js'));
app.use('/dist', express.static(__dirname + '/dist'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/', routes);
//https server
// https.createServer({
//     key: fs.readFileSync('server.key'),
//     cert: fs.readFileSync('server.cert')
//   }, app)
//   .listen(3000, function () {
//     console.log('App listening on port 3000! Go to https://localhost:3000/')
//   })
//http server
app.listen(port, function() {
    console.log('Server listening on port ' + port);
    console.log('Open in browser: http://localhost:' + port);
});