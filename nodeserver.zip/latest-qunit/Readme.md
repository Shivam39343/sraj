# Qunit

## I have created a node server for this project now the project will run through node server not by file protocol.
 
 ## Prerequirements:-
  1. Install node modules by writting command (npm install).
  2. Install browserify globally by writting command (npm i -g browserify).
  3. Install watchify globally by writting command (npm i -g watchify).
 
 
## Steps:-
  1. command to run our project on browser at http://localhost:3000  (npm start: "node app").
  2. command to build our test.js(node file )into browser javascript and and compiles our project regularly if any changes are madein test.js(npm build: "watchify js/test.js -o dist/test.js").
  3. command to run our project in command Line (npm test: "qunit js/test.js").
### Commands
#### install modules
npm install
#### build code and watch changes
npm run build
#### Run into browser
npm start 
#### Run into console
npm run test
   


## Note:- project will run on both on localhost(http://localhost:3000 ) as well as command line. Before running the code don't forget to build the project.